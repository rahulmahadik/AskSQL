CREATE TABLE regions (code TEXT, name TEXT);
INSERT INTO regions VALUES ('EU', 'Europe'), ('NA', 'North America');
